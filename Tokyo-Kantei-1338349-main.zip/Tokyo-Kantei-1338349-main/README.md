This customer's accounts are being managed from the console with one exception.
hyoka_admin is being managed via terraform.

# Green/Brown
[Green]

489746979994 - (Tokyo Kantei_Appraiser Support Production) - In Support

931756137289 - (Tokyo Kantei_hyoka_cloud) - In Support (PE)

126791008945 - (datanavi) - In Support

505982390831 - (hyoka_admin) - In Support

[Brown]

182207173840 - (robot) - In Support

286325778687 - (datalake) - In Support

528041163687 - (ml) - In Support

# hyoka_admin 
This account is being managed via terraform and will be a blueprint for future customer accounts. 
It is setup as a management account with other accounts to be added in the future.
3 Components are deployed in this account:
1. Basic Infrastructure - https://one.rackspace.com/display/maws/505982390831+-+%28Tokyo+Kantei%29+hyoka_admin?searchId=EXCUB5FEB
2. CICD Pipeline for Lambda Deployment - https://one.rackspace.com/display/maws/505982390831+-+%28Tokyo+Kantei%29+hyoka_admin+-+CICD+Pipeline
3. Log Centralizaion (configures as monitoring account) - https://one.rackspace.com/display/maws/505982390831+-+%28Tokyo+Kantei%29+hyoka_admin+-+Log+Centralization